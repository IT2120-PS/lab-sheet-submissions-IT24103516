setwd("C:\\Users\\IT24102186\\Desktop\\IT24102186")
x <-c(1,2,3)
x[1]/x[2]^3-1+2*x[3] -x[2-1]
,

#2
sum(1.15 %% 3 == 0)
v <- c(10,12,25,14,9)
max_index <- 1
for (i in 2:1length (v)) {
  if (v[i]> v[max_index]){
    max_index <- i
  }
}

max_index


which.max(v)


#Q3

vec <- c(3,5,2,9,7)
max_index <- 1
for (i in 2:length(vec)) {
  if(vec[i] > vec[max_index]) {
    max_index <- i
  }
}
print(max_index)


#Q4
vec <-c(3,5,2,9,7)
max_index <- which.max(vec)
print(max_index)
